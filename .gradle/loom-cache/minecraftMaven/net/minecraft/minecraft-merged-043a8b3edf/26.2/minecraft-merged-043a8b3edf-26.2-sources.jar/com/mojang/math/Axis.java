package com.mojang.math;

import org.joml.Quaternionf;
import org.joml.Vector3f;

@FunctionalInterface
public interface Axis {
	Axis XN = /* lambda$static$0 */ angle -> new Quaternionf().rotationX(-angle);
	Axis XP = /* lambda$static$1 */ angle -> new Quaternionf().rotationX(angle);
	Axis YN = /* lambda$static$2 */ angle -> new Quaternionf().rotationY(-angle);
	Axis YP = /* lambda$static$3 */ angle -> new Quaternionf().rotationY(angle);
	Axis ZN = /* lambda$static$4 */ angle -> new Quaternionf().rotationZ(-angle);
	Axis ZP = /* lambda$static$5 */ angle -> new Quaternionf().rotationZ(angle);

	static Axis of(final Vector3f vector) {
		return /* lambda$of$0 */ angle -> new Quaternionf().rotationAxis(angle, vector);
	}

	Quaternionf rotation(float angle);

	default Quaternionf rotationDegrees(final float angle) {
		return this.rotation(angle * (float) (Math.PI / 180.0));
	}
}
